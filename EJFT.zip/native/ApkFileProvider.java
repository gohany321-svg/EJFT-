package com.ejft.app;

import androidx.core.content.FileProvider;

public class ApkFileProvider extends FileProvider {}
