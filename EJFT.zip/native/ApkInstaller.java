package com.ejft.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.core.content.FileProvider;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

@CapacitorPlugin(name = "ApkInstaller")
public class ApkInstaller extends Plugin {

    @PluginMethod
    public void canInstall(PluginCall call) {
        boolean ok = Build.VERSION.SDK_INT < 26 || getContext().getPackageManager().canRequestPackageInstalls();
        JSObject r = new JSObject();
        r.put("ok", ok);
        call.resolve(r);
    }

    @PluginMethod
    public void openSettings(PluginCall call) {
        Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getContext().getPackageName()));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
        call.resolve();
    }

    @PluginMethod
    public void download(final PluginCall call) {
        final String u = call.getString("url");
        if (u == null) { call.reject("no url"); return; }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    HttpURLConnection h = (HttpURLConnection) new URL(u).openConnection();
                    h.setConnectTimeout(20000);
                    h.setReadTimeout(30000);
                    h.connect();
                    if (h.getResponseCode() != 200) { call.reject("HTTP " + h.getResponseCode()); return; }
                    int total = h.getContentLength();
                    File f = new File(getContext().getCacheDir(), "EJFT.apk");
                    InputStream in = h.getInputStream();
                    FileOutputStream out = new FileOutputStream(f);
                    byte[] b = new byte[16384];
                    int n;
                    long got = 0;
                    int last = -1;
                    while ((n = in.read(b)) > 0) {
                        out.write(b, 0, n);
                        got += n;
                        int pc = total > 0 ? (int) (got * 100 / total) : 0;
                        if (pc != last) {
                            last = pc;
                            JSObject o = new JSObject();
                            o.put("pct", pc);
                            o.put("got", got);
                            o.put("total", total);
                            notifyListeners("progress", o);
                        }
                    }
                    out.close();
                    in.close();
                    JSObject r = new JSObject();
                    r.put("path", f.getAbsolutePath());
                    call.resolve(r);
                } catch (Exception e) {
                    call.reject(String.valueOf(e.getMessage()));
                }
            }
        }).start();
    }

    @PluginMethod
    public void install(PluginCall call) {
        String p = call.getString("path");
        if (p == null) { call.reject("no path"); return; }
        try {
            File f = new File(p.replace("file://", ""));
            Uri u = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".apkprovider", f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }
}
